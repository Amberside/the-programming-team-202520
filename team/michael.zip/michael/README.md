Holmesglen Programming Team 2025 Semester 2

-- Title -- 

Revision notes for Michael's personalised fork of the Programming Team member profile pages (*.html)

-- Publication Date --

This fork was created on Friday 8th August 2025 to develop a Programming Team Member profile page.

-- Revision Notes --

---- Date: Friday 8th August 2025 ----

 First brief draft to test local repository and creation of branch from main work using GitHub Desktop to import and edit with Visual Studio Code, before creating a fork of the main GitHun team directory.

 Creation of fork on Team GitHub appears successful.

 This entry was edited directly via the Programming Team GitHub via FIrefox, and will be saved if write permission allow this.

---- Outcome -----

Editing repo files directly, rather than remotely editing and then pushing to the Programmng Team GitHub, for simple tasks like brief revision notes, appears to be quite workable.

A local pull request will test if changes made directly to the GitHub repos are propogated to my local folder.

Tascoast

---- Date: --

---- Outcome -----

 
